start.addEventListener("click", () => {
    console.log("gomb megnyomva");
    });